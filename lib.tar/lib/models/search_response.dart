class SearchResponse {
  final SearchQuery query;
  final List<SearchBandItem> bands;
  final List<SearchVenueItem> venues;
  final List<SearchEventItem> events;

  const SearchResponse({
    required this.query,
    required this.bands,
    required this.venues,
    required this.events,
  });

  factory SearchResponse.fromJson(Map<String, dynamic> json) {
    final data = (json['data'] as Map<String, dynamic>? ?? {});

    final bandsList = _extractList(data['bands']);
    final venuesList = _extractList(data['venues']);
    final eventsList = _extractList(data['events']);

    return SearchResponse(
      query: SearchQuery.fromJson(
        (data['query'] as Map?)?.cast<String, dynamic>() ?? {},
      ),
      bands: bandsList
          .map(
            (e) => SearchBandItem.fromJson((e as Map).cast<String, dynamic>()),
          )
          .toList(),
      venues: venuesList
          .map(
            (e) => SearchVenueItem.fromJson((e as Map).cast<String, dynamic>()),
          )
          .toList(),
      events: eventsList
          .map(
            (e) => SearchEventItem.fromJson((e as Map).cast<String, dynamic>()),
          )
          .toList(),
    );
  }

  static List _extractList(dynamic value) {
    if (value is List) {
      return value;
    }

    if (value is Map<String, dynamic>) {
      final inner = value['data'];
      if (inner is List) {
        return inner;
      }
    }

    if (value is Map) {
      final inner = value['data'];
      if (inner is List) {
        return inner;
      }
    }

    return const [];
  }
}

class SearchQuery {
  final String q;
  final String? region;
  final String? provinceCode;
  final String? city;
  final String? startDate;
  final String? endDate;
  final int? limit;

  const SearchQuery({
    required this.q,
    this.region,
    this.provinceCode,
    this.city,
    this.startDate,
    this.endDate,
    this.limit,
  });

  factory SearchQuery.fromJson(Map<String, dynamic> json) {
    return SearchQuery(
      q: (json['q'] ?? '').toString(),
      region: json['region']?.toString(),
      provinceCode: json['province_code']?.toString(),
      city: json['city']?.toString(),
      startDate: json['start_date']?.toString(),
      endDate: json['end_date']?.toString(),
      limit: _asInt(json['limit']),
    );
  }
}

class SearchBandItem {
  final int id;
  final String name;
  final String? city;
  final String? provinceCode;
  final String? region;

  const SearchBandItem({
    required this.id,
    required this.name,
    this.city,
    this.provinceCode,
    this.region,
  });

  factory SearchBandItem.fromJson(Map<String, dynamic> json) {
    final location = (json['location'] as Map<String, dynamic>? ?? {});
    return SearchBandItem(
      id: _asInt(json['id']) ?? 0,
      name: (json['name'] ?? '').toString(),
      city: location['city']?.toString() ?? location['name']?.toString(),
      provinceCode: location['province_code']?.toString(),
      region: location['region']?.toString(),
    );
  }
}

class SearchVenueItem {
  final int id;
  final String name;
  final String? city;
  final String? provinceCode;
  final String? region;
  final String? address;

  const SearchVenueItem({
    required this.id,
    required this.name,
    this.city,
    this.provinceCode,
    this.region,
    this.address,
  });

  factory SearchVenueItem.fromJson(Map<String, dynamic> json) {
    final location = (json['location'] as Map<String, dynamic>? ?? {});

    return SearchVenueItem(
      id: _asInt(json['id']) ?? 0,
      name: (json['name'] ?? '').toString(),
      city: location['city']?.toString() ?? location['name']?.toString(),
      provinceCode: location['province_code']?.toString(),
      region: location['region']?.toString(),
      address: json['address']?.toString(),
    );
  }
}

class SearchEventItem {
  final int id;
  final String title;
  final String? startDatetime;
  final String? endDatetime;
  final String? venueName;
  final String? locationName;
  final String? provinceCode;

  const SearchEventItem({
    required this.id,
    required this.title,
    this.startDatetime,
    this.endDatetime,
    this.venueName,
    this.locationName,
    this.provinceCode,
  });

  factory SearchEventItem.fromJson(Map<String, dynamic> json) {
    final venue = (json['venue'] as Map<String, dynamic>? ?? {});
    final location = (venue['location'] as Map<String, dynamic>? ?? {});

    return SearchEventItem(
      id: _asInt(json['id']) ?? 0,
      title: (json['title'] ?? '').toString(),
      startDatetime: json['start_datetime']?.toString(),
      endDatetime: json['end_datetime']?.toString(),
      venueName: venue['name']?.toString(),
      locationName:
          location['name']?.toString() ?? location['city']?.toString(),
      provinceCode: location['province_code']?.toString(),
    );
  }
}

int? _asInt(dynamic value) {
  if (value is int) return value;
  if (value == null) return null;
  return int.tryParse(value.toString());
}
